#布林值 tf大寫
True
False
#數字
321333.5
#字串
"abc"
#list 有順序可動的列表
[3,4,5]
#Tuple 有順序不可動的列表 
(3,4,5)
#set 集合 無順序
{3,4,5}
#字典 dictionary
{"apple":"蘋果","data":"資料"}
#變數 
data=3
lis=[3,5,4]
print(lis)
lis=3
print(lis)