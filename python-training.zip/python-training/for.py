for i in range(15):
    print("a")
