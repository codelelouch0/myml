#grades=[12,60,15,70,90]
#print(grades)
#grades[1:4]=[]#連續刪除列表1-4(不包括)
#print(grades)
#grades+=[12,33]
#print(grades)
#length=len(grades)
#print(length)


#巢狀列表
#data=[[3,4,5],[6,7,8]]
#print(data)
#data[0][0:2]=[5,5,5]
#print(data)

#tuple 中資料不可變動
data = [1,2]
data0 = [3,4]
data = data0
print(data)

