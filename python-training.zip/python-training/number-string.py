x=3//6
print(x)
x=x*1
print(x)