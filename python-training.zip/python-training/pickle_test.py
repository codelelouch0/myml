import pickle

file = open('ml_HARD1.pickle','rb')
backup_list = pickle.load(file)
file.close()
print(len(backup_list))
file = open('arkanoid_dataset.pickle','rb')
backup_list2 = pickle.load(file)
file.close()
print(len(backup_list2))
backup_list = backup_list + backup_list2
print(len(backup_list))
