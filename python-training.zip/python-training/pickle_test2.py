import pickle

file = open('clf_SVMClassification_VectorsAndDirection.pickle','rb')
backup_list = pickle.load(file)
file.close()
print(backup_list)