import pickle 
import os
import random
from os import walk
from os.path import join

# 指定要列出所有檔案的目錄
mypath = "/Users/codel/Desktop/python-training/log"
data = []
# 遞迴列出所有檔案的絕對路徑
for root, dirs, files in walk(mypath):
    for f in files:
        d = open(mypath+'/'+f,'rb')
        backup_list = pickle.load(d)
        d.close()
        data = data + backup_list

N = []
R = []
L = []

for i in data:
    if i["command_1P"]=="NONE":
        N.append(i)
    if i["command_1P"]=="MOVE_RIGHT":
        R.append(i)
    if i["command_1P"]=="MOVE_LEFT":
        L.append(i)
c=0
NN = []
while c<=len(N)/4:
    a = random.randint(0,len(N)-1)
    NN.append(N[a])
    c = c + 1



dataN = NN + R + L

count=[0,0,0]
for i in dataN:
    if i["command_1P"]=="NONE":
        count[0] = count[0] + 1
    if i["command_1P"]=="MOVE_RIGHT":
        count[1] = count[1] + 1
    if i["command_1P"]=="MOVE_LEFT":
        count[2] = count[2] + 1

print(count)

with open('save/pingpong_dataset.pickle', 'wb') as f:
        pickle.dump(dataN, f)


