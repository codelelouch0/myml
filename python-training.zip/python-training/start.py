print("Hello python")
for i in range(15):
    print(i)